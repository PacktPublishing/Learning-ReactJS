require 'json'

data = File.read("data.json")
data_hash = JSON.parse(data)

html = "
<html>
<body>
  <ul>"

data_hash["books"].each do |book|
  html += "
    <li>
      #{book["title"]} - #{book["price"]}
    </li>
  "
end

html += "
  </ul>
</body>
</html>

"

File.write("books.html", html)
